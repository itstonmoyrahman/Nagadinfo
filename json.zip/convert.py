import json

# Function to convert the text data to JSON
def text_to_json(file_path):
    data = []
    subject = chapter = title = ""

    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()

            if line.startswith("Subject:"):
                subject = line.split(":", 1)[1].strip()

            elif line.startswith("Chapter:"):
                chapter = line.split(":", 1)[1].strip()

            elif line.startswith("Title:"):
                title = line.split(":", 1)[1].strip()

            elif line.startswith("Bunny URL:"):
                url = line.split(":", 1)[1].strip()
                # Add the complete entry to the data list
                data.append({
                    "subject": subject,
                    "chapter": chapter,
                    "title": title,
                    "url": url
                })

    # Convert the list to JSON
    return json.dumps(data, ensure_ascii=False, indent=4)

# Specify the file path
file_path = "data.txt"

# Get JSON output
json_output = text_to_json(file_path)

# Save to a JSON file
output_file = "output.json"
with open(output_file, 'w', encoding='utf-8') as f:
    f.write(json_output)

print(f"JSON data saved to {output_file}")
