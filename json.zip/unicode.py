import json

# Function to read JSON, decode, and save it back
def decode_json(input_file, output_file):
    try:
        # Read the JSON file
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # If needed, convert any string fields with Unicode escape sequences
        # This step is optional as json.load automatically handles Unicode
        # Here we just ensure it's in the correct format
        decoded_data = {key: value.encode().decode('unicode_escape') if isinstance(value, str) else value for key, value in data.items()}

        # Save the decoded data to a new JSON file
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(decoded_data, f, ensure_ascii=False, indent=4)

        print(f"Data successfully read from {input_file} and saved to {output_file}.")

    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage
input_json_file = 'response.json'  # Replace with your input file
output_json_file = 'output.json'  # Replace with your desired output file
decode_json(input_json_file, output_json_file)
