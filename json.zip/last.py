import os
import json
from telegram import Bot
import subprocess

# Function to download a video using yt-dlp
def download_video(url, filename):
    try:
        # Construct the yt-dlp command with header
        command = [
            'yt-dlp',
            url,
            '--add-header', 'Referer: https://www.softmaxonline.com/',
            '-o', filename  # Save as the provided filename
        ]
        subprocess.run(command, check=True)
        print(f"Downloaded: {filename}")
    except subprocess.CalledProcessError as e:
        print(f"Error downloading {url}: {str(e)}")

# Function to send a file to a Telegram chat
def send_to_telegram(file_path, chat_id, bot_token):
    bot = Bot(token=bot_token)
    with open(file_path, 'rb') as video:
        bot.send_video(chat_id=chat_id, video=video)
    print(f"Sent: {file_path} to chat_id: {chat_id}")

# Read the JSON file
json_file = 'output.json'  # Update the path accordingly
with open(json_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Telegram Bot credentials
chat_id = '5564348463'
bot_token = '7226691493:AAECigA1TZfyE_-T_mfQxFF5pIcETaZQdCA'

# Loop through each entry in the JSON data
for idx, entry in enumerate(data, 1):
    subject = entry['subject']
    chapter = entry['chapter']
    url = entry['url']

    # Create the filename based on the subject and chapter
    filename = f"{subject}_{chapter}_({idx}).mp4"
    
    # Download the video using yt-dlp
    download_video(url, filename)
    
    # Send the video to Telegram
    send_to_telegram(filename, chat_id, bot_token)

    # Optional: Remove the video file after sending
    os.remove(filename)
    print(f"Removed: {filename}")
