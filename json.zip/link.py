import requests
import json

# Define the URL and the headers
url = "http://softmaxmanager.xyz/api/v1/academic/enrolled/subject/details/"
headers = {
    "User-Agent": "Dart/3.5 (dart:io)",
    "Accept": "application/json",
    "Accept-Encoding": "gzip",
    "X-App-Key": "GktPbcpxapY",
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzQwOTU0MDczLCJpYXQiOjE3Mjc5OTQwNzMsImp0aSI6ImEwMmY4NWU5N2YwZDRjZWE5Y2IwMzM1ZWYzOGFjYWVlIiwidXNlcl9pZCI6MTEyODE3fQ.NHuookQm7KS0q_I2LNySK7Ki_B8-7mRw-sz2FlT5aJE",
    "Content-Type": "application/json; charset=utf-8"
}

# Define the payload
data = {
    "course": 168,
    "subject": None,
    "type": "basic"
}

# Make the POST request
response = requests.post(url, headers=headers, json=data)

# Check if the request was successful
if response.status_code == 200:
    # Save the response to response.json
    with open('response.json', 'w') as f:
        json.dump(response.json(), f, indent=4)
    print("Response saved to response.json")
else:
    print(f"Request failed with status code: {response.status_code}")
