import json

# Function to collect video links from the JSON structure
def collect_video_links_from_json(file_path):
    video_links = []
    with open(file_path, 'r') as file:
        data = json.load(file)

        # Loop through the data to extract relevant information
        for item in data['data']:
            subject_name = item.get('name', 'No Subject Name')
            if 'chapters' in item:
                for chapter in item['chapters']:
                    chapter_name = chapter.get('name', 'No Chapter Name')
                    if 'package' in chapter:
                        for package in chapter['package']:
                            if 'videos' in package:
                                for video in package['videos']:
                                    title = video.get('title', 'No Title')
                                    youtube_link = video.get('youtube_link', '')
                                    bunny_url = video.get('bunny_url', '')
                                    
                                    # Add formatted data to the list
                                    video_links.append({
                                        'subject': subject_name,
                                        'chapter': chapter_name,
                                        'title': title,
                                        'bunny_url': bunny_url,
                                        'youtube_link': youtube_link
                                    })

    return video_links

# Function to save formatted video links to a text file
def save_video_links_to_file(video_links, output_file):
    with open(output_file, 'w') as file:
        for link in video_links:
            file.write(f"Subject: {link['subject']}\n")
            file.write(f"Chapter: {link['chapter']}\n")
            file.write(f"Title: {link['title']}\n")
            if link['bunny_url']:
                file.write(f"Bunny URL: {link['bunny_url']}\n")
            if link['youtube_link']:
                file.write(f"YouTube Link: {link['youtube_link']}\n")
            file.write("\n")  # New line for better separation

# Path to your JSON file
file_path = 'output.json'
output_file = 'formatted_links.txt'

# Collect and save video links
collected_video_links = collect_video_links_from_json(file_path)
save_video_links_to_file(collected_video_links, output_file)

print(f"Formatted video links saved to {output_file}")
